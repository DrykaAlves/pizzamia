module.exports = function(app) {
	var Usuario = app.models.usuario;
	var PedidoController = {
		index: function(req, res) {
			var _id = req.session.usuario._id;
			Usuario.findById(_id, function (erro, usuario) {
				var pedidos = usuario.pedidos;
				var resultado = { pedidos: pedidos, nome: usuario.nome };
				res.render('pedidos/index', resultado);
			});
		},		
		create: function(req, res) {
			var _id = req.session.usuario._id;
			Usuario.findById(_id, function(erro, usuario) {
				var pedido = req.body.pedido;
				var pedidos = usuario.pedidos;
				pedidos.push(pedido);
				usuario.save(function() {
					res.redirect('/pedidos');
				});
			});
		},
		show: function(req, res) {
			var _id = req.session.usuario._id;
			Usuario.findById(_id, function(erro, usuario) {
				var pedidoID = req.params.id;
				var pedido = usuario.pedidos.id(pedidoID);
				var resultado = { pedido: pedido };
				res.render('pedidos/show', resultado);
			});
		},
		edit: function(req, res) {
			var _id = req.session.usuario._id;
			Usuario.findById(_id, function(erro, usuario) {
				var pedidoID = req.params.id;
				var pedido = usuario.pedidos.id(pedidoID);
				var resultado = { pedido: pedido };
				res.render('pedidos/edit', resultado);
			});
		},
		update: function(req, res) {
			var _id = req.session.usuario._id;
			Usuario.findById(_id, function(erro, usuario) {
				var pedidoID = req.params.id;
				var pedido = usuario.pedidos.id(pedidoID);
				pedido.nome = req.body.pedido.nome;
				pedido.endereco = req.body.pedido.endereco;
				pedido.sabores = req.body.pedido.sabores;
				usuario.save(function() {
					res.redirect('/pedidos');
				});
			});
		},
		destroy: function(req, res) {
			var _id = req.session.usuario._id;
			Usuario.findById(_id, function(erro, usuario) {
				var pedidoID = req.params.id;
				usuario.pedidos.id(pedidoID).remove();
				usuario.save(function() {
					res.redirect('/pedidos');
				});
			});
		}
	}
	
	return PedidoController;
};