module.exports = function(app) {
	var Usuario = app.models.usuario;
	var HomeController = {
		index: function(req, res) {
			res.render('home/index');
		},
		login: function(req, res) {
			var query = {senha: req.body.usuario.senha, nome: req.body.usuario.nome};
			Usuario.findOne(query)
			.select('nome senha perfil')
			.exec(function(erro, usuario){
				if (usuario) {
					req.session.usuario = usuario;
					if (req.body.usuario.perfil == 'cliente') {	
						res.redirect('/pedidos');
					} else {
						res.redirect('/admin');
					}
				} else {
					Usuario.create(req.body.usuario, function(erro, usuario) {
						if(erro){
							res.redirect('/');
						} else {
							req.session.usuario = usuario;
							if (req.body.usuario.perfil == 'cliente') {	
								res.redirect('/pedidos');
							} else {
								res.redirect('/admin');
							}
						}
					});
				}
			});
		},
		logout: function(req, res) {
			req.session.destroy();
			res.redirect('/');
		}
	};
	return HomeController;
};