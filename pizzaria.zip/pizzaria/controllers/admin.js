module.exports = function (app) {
	var Usuario = app.models.usuario;
	var AdminController = {
		index: function (req, res) {
			var nome = req.session.usuario.nome;
			Usuario.find({perfil: "cliente"}, function (erro, usuario) {
				if (erro) throw erro;
				var resultado = { usuario: usuario, nomeU: nome };
				res.render('admin/index', resultado);
			});
		},
		show: function (req, res) {
			var _id = req.params.id;
			Usuario.findById(_id, function (erro, usuario) {
				if(erro) throw erro;
				var pedidos = usuario.pedidos;
				var resultado = { pedidos: pedidos, nome: usuario.nome, idUser: usuario.id};
				res.render('admin/show', resultado);
			});
		},
		edit: function(req, res) {
			var user = req.params.user;
			Usuario.findById(user, function(erro, usuario) {
				if(erro) throw erro;
				var pedidoID = req.params.id;
				var pedidos = usuario.pedidos.id(pedidoID);
				var resultado = { pedidos: pedidos, userId: user };
				res.render('admin/edit', resultado);
			});
		},
		update: function(req, res) {
			var user = req.params.userId;
			Usuario.findById(user, function(erro, usuario) {
				if(erro) throw erro;
				var pedidoID = req.params.id;
				var pedido = usuario.pedidos.id(pedidoID);
				pedido.status = req.body.pedido.status;
				usuario.save(function() {
					res.redirect("/admin");
				});
			});
		}
	}
	return AdminController;
};