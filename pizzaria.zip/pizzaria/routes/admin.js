module.exports = function(app) {
	var  autenticar = require('./../middleware/autenticador.js')
		,admin = app.controllers.admin;
	app.get('/admin', autenticar, admin.index);
	app.get('/admin/:id', autenticar, admin.show);
	app.get('/admin/:id&:user/editar', autenticar, admin.edit);
	app.put('/admin/:id&:userId', autenticar, admin.update);
};