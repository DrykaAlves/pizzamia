module.exports = function(app) {
	var autenticar = require('./../middleware/autenticador.js')
		, pedidos = app.controllers.pedidos;
	app.get('/pedidos', autenticar, pedidos.index);
	app.get('/pedidos/:id', autenticar, pedidos.show);
	app.post('/pedidos', autenticar, pedidos.create);
	app.get('/pedidos/:id/editar', autenticar, pedidos.edit);
	app.put('/pedidos/:id', autenticar, pedidos.update);
	app.delete('/pedidos/:id', autenticar, pedidos.destroy);
};