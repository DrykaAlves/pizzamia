module.exports = function(app) {
	var Schema = require('mongoose').Schema;
	var pedido = Schema({
		nome: String
		, endereco: String
		, sabores : String
		, status: String
	});
	var usuario = Schema({
		nome: {type: String, required: true
		, index: {unique: true}}
		, perfil: {type: String, required: true}
		, senha: {type: String, required: true}
		, pedidos: [pedido]
	});
	
	return db.model('usuarios', usuario);
};